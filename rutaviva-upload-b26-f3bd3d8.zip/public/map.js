import { Map, NavigationControl, setWorkerUrl } from '/vendor/maplibre/maplibre-gl.mjs';

setWorkerUrl('/vendor/maplibre/maplibre-gl-worker.mjs');
let map; let ready=false; let drawing=false; let points=[]; let onPoints=()=>{}; let onSelect=()=>{}; let contributions=[];
const fc = features => ({ type:'FeatureCollection', features });
const featureFor = item => ({ type:'Feature', geometry:item.geometry, properties:{ id:item.id, status:item.status, kind:item.kind, title:item.title } });
function drawFeature(){ return points.length ? [{ type:'Feature', geometry:points.length===1?{type:'Point',coordinates:points[0]}:{type:'LineString',coordinates:points}, properties:{} }] : []; }
function refreshSource(name,data){ if(ready&&map.getSource(name)) map.getSource(name).setData(fc(data)); }
function refreshDraw(){ refreshSource('drawing',drawFeature()); onPoints([...points]); }
export function initCommunityMap({center,tileUrl,select,status,pointsChanged}){
  onSelect=select||onSelect; onPoints=pointsChanged||onPoints;
  map=new Map({container:'map',center:[center.longitude,center.latitude],zoom:12.4,style:{version:8,sources:{osm:{type:'raster',tiles:[tileUrl],tileSize:256,attribution:'© OpenStreetMap contributors'}},layers:[{id:'osm',type:'raster',source:'osm'}]}});
  map.addControl(new NavigationControl({showCompass:false}),'top-right');
  map.on('load',()=>{ ready=true; map.addSource('contributions',{type:'geojson',data:fc(contributions.map(featureFor))}); map.addLayer({id:'community-lines',type:'line',source:'contributions',filter:['==',['geometry-type'],'LineString'],paint:{'line-color':['case',['==',['get','status'],'published'],'#16745a','#d8762c'],'line-width':6,'line-opacity':.9}}); map.addLayer({id:'community-points',type:'circle',source:'contributions',filter:['==',['geometry-type'],'Point'],paint:{'circle-radius':8,'circle-color':['case',['==',['get','status'],'published'],'#16745a','#d8762c'],'circle-stroke-color':'#fff','circle-stroke-width':3}}); map.addSource('drawing',{type:'geojson',data:fc(drawFeature())}); map.addLayer({id:'drawing-line',type:'line',source:'drawing',paint:{'line-color':'#2457d6','line-width':5,'line-dasharray':[2,1]}}); map.addLayer({id:'drawing-point',type:'circle',source:'drawing',paint:{'circle-radius':6,'circle-color':'#2457d6','circle-stroke-color':'#fff','circle-stroke-width':2}}); for(const layer of ['community-lines','community-points']) map.on('click',layer,event=>onSelect(event.features?.[0]?.properties?.id)); status?.('Mapa preparado.'); refreshDraw(); });
  map.on('click',event=>{ if(drawing&&points.length<50){ points.push([Number(event.lngLat.lng.toFixed(6)),Number(event.lngLat.lat.toFixed(6))]); refreshDraw(); }});
  map.on('error',()=>status?.('No se pudo cargar parte del mapa. La lista sigue disponible.'));
}
export function setMapContributions(items){ contributions=items||[]; refreshSource('contributions',contributions.map(featureFor)); }
export function startDrawing(){ drawing=true; }
export function stopDrawing(){ drawing=false; }
export function addCenterPoint(){ if(map&&points.length<50){ const c=map.getCenter(); points.push([Number(c.lng.toFixed(6)),Number(c.lat.toFixed(6))]); refreshDraw(); }}
export function undoPoint(){ points.pop(); refreshDraw(); }
export function clearDrawing(){ points=[]; refreshDraw(); }
export function geometryFor(kind){ if(!points.length)return null; if(['barrier','closure','lighting'].includes(kind))return{type:'Point',coordinates:points.at(-1)}; return points.length<2?null:{type:'LineString',coordinates:[...points]}; }
export function focusContribution(item){ if(!map||!item?.geometry)return; const pts=item.geometry.type==='Point'?[item.geometry.coordinates]:item.geometry.coordinates; const lng=pts.reduce((s,p)=>s+p[0],0)/pts.length; const lat=pts.reduce((s,p)=>s+p[1],0)/pts.length; map.flyTo({center:[lng,lat],zoom:15,essential:false}); }
